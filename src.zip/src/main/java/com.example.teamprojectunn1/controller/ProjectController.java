package com.example.teamprojectunn1.controller;

import com.example.teamprojectunn1.dto.ProjectDto;
import com.example.teamprojectunn1.dto.CreateProjectRequest;
import com.example.teamprojectunn1.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/projects")
public class ProjectController {

    @Autowired
    private ProjectService projectService;

    @PostMapping
    public ResponseEntity<?> createProject(@RequestBody CreateProjectRequest request, Authentication authentication) {
        String userEmail = authentication.getName();
        try {
            ProjectDto createdProject = projectService.createProject(request, userEmail);
            return ResponseEntity.ok(createdProject);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Ошибка при создании проекта: " + e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getProject(@PathVariable Long id) {
        try {
            ProjectDto project = projectService.getProjectById(id);
            return ResponseEntity.ok(project);
        } catch (Exception e) {
            return ResponseEntity.status(404).body("Проект не найден");
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateProject(@PathVariable Long id,
                                           @RequestBody CreateProjectRequest request,
                                           Authentication authentication) {
        String userEmail = authentication.getName();
        try {
            ProjectDto updatedProject = projectService.updateProject(id, request, userEmail);
            return ResponseEntity.ok(updatedProject);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Ошибка при обновлении проекта: " + e.getMessage());
        }
    }
}