package com.example.teamprojectunn1.controller;

import com.example.teamprojectunn1.dto.SkillDto;
import com.example.teamprojectunn1.dto.UserProfileDto;
import com.example.teamprojectunn1.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "http://localhost:5173")

public class UserController {
    private final UserService userService;
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/me")
    public ResponseEntity<?> getCurrentUser(Authentication authentication) {
        if (authentication == null) {
            return ResponseEntity.status(401).body("Пользователь не авторизован");
        }
        return ResponseEntity.ok(userService.getUserProfile(authentication.getName()));
    }

    @PutMapping("/profile")
    public ResponseEntity<?> updateProfile(@RequestBody UserProfileDto profileDto, Authentication authentication) {
        try {
            userService.updateProfile(authentication.getName(), profileDto);
            return ResponseEntity.ok("Профиль успешно обновлен");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Ошибка обновления: " + e.getMessage());
        }
    }

    @PostMapping("/skills")
    public ResponseEntity<?> addSkill(@RequestBody SkillDto skillDto, Authentication authentication) {
        try {
            userService.addSkillToUser(authentication.getName(), skillDto);
            return ResponseEntity.ok("Навык успешно добавлен");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Ошибка: " + e.getMessage());
        }
    }

    @DeleteMapping("/skills/{skillId}")
    public ResponseEntity<?> removeSkill(@PathVariable Long skillId, Authentication authentication) {
        try {
            userService.removeSkillFromUser(authentication.getName(), skillId);
            return ResponseEntity.ok("Навык удален");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Ошибка: " + e.getMessage());
        }
    }
}