package com.example.teamprojectunn1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeamProjectUnn1Application {
    public static void main(String[] args) {
        SpringApplication.run(TeamProjectUnn1Application.class, args);
    }
}
