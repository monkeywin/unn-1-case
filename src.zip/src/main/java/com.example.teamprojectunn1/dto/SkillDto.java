package com.example.teamprojectunn1.dto;

public record SkillDto(
        Long id,
        String name
) {
}