package com.example.teamprojectunn1.dto;

public record ProjectDto(
        Long id,
        String title,
        String description,
        String techStack,
        String requiredRoles,
        String ownerEmail
) {
}