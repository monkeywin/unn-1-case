package com.example.teamprojectunn1.dto;

public record CreateProjectRequest(
        String title,
        String description,
        String techStack,
        String requiredRoles
) {
}