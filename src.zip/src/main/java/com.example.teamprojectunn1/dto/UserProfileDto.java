package com.example.teamprojectunn1.dto;

import java.util.List;

public record UserProfileDto(
        Long id,
        String username,
        String name,
        String bio,
        List<String> skills
) {
}