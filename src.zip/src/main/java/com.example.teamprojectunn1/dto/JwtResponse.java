package com.example.teamprojectunn1.dto;

public record JwtResponse(String token) {
}
