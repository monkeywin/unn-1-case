package com.example.teamprojectunn1.dto;

public record LoginRequest(String email, String password) {
}
