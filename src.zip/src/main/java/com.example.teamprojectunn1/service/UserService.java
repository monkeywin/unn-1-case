package com.example.teamprojectunn1.service;

import com.example.teamprojectunn1.dto.SkillDto;
import com.example.teamprojectunn1.dto.UserProfileDto;
import com.example.teamprojectunn1.entity.User;
import com.example.teamprojectunn1.repository.UserRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;

@Service
public class UserService implements UserDetailsService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("Пользователь не найден: " + username));

        return org.springframework.security.core.userdetails.User
                .withUsername(user.getUsername())
                .password(user.getPassword())
                .authorities(Collections.emptyList())
                .build();
    }

    public UserProfileDto getUserProfile(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));


        return new UserProfileDto(
                user.getId(),
                user.getUsername(),
                user.getName(),
                user.getBio(),
                user.getSkills()
        );
    }

    @Transactional
    public void updateProfile(String username, UserProfileDto profileDto) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Пользователь не найден"));

        // В record вместо getName() вызывается name(), вместо getBio() -> bio()
        user.setName(profileDto.name());
        user.setBio(profileDto.bio());
        userRepository.save(user);
    }

    @Transactional
    public void addSkillToUser(String username, SkillDto skillDto) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Пользователь не найден"));

        // Если SkillDto тоже record, используем skillDto.name()
        String skillName = skillDto.name();

        if (skillName != null && !user.getSkills().contains(skillName)) {
            user.getSkills().add(skillName);
            userRepository.save(user);
        }
    }

    @Transactional
    public void removeSkillFromUser(String username, Long skillId) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Пользователь не найден"));

        if (user.getSkills() != null && skillId >= 0 && skillId < user.getSkills().size()) {
            user.getSkills().remove(skillId.intValue());
            userRepository.save(user);
        }
    }
}