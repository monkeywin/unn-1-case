package com.example.teamprojectunn1.service;

import com.example.teamprojectunn1.dto.CreateProjectRequest;
import com.example.teamprojectunn1.dto.ProjectDto;
import com.example.teamprojectunn1.entity.Project;
import com.example.teamprojectunn1.entity.User;
import com.example.teamprojectunn1.repository.ProjectRepository;
import com.example.teamprojectunn1.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProjectService {

    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private UserRepository userRepository;

    @Transactional
    public ProjectDto createProject(CreateProjectRequest request, String ownerEmail) {
        User owner = userRepository.findByEmail(ownerEmail)
                .orElseThrow(() -> new UsernameNotFoundException("Пользователь не найден: " + ownerEmail));

        Project project = new Project();
        project.setTitle(request.title());
        project.setDescription(request.description());
        project.setTechStack(request.techStack());
        project.setRequiredRoles(request.requiredRoles());
        project.setOwner(owner); // Устанавливаем связь с владельцем

        Project savedProject = projectRepository.save(project);
        return mapToDto(savedProject);
    }

    @Transactional
    public ProjectDto updateProject(Long projectId, CreateProjectRequest request, String userEmail) {
        Project project = projectRepository.findById(projectId)
                .orElseThrow(() -> new RuntimeException("Проект не найден"));

        if (!project.getOwner().getEmail().equals(userEmail)) {
            throw new RuntimeException("У вас нет прав для редактирования этого проекта");
        }

        project.setTitle(request.title());
        project.setDescription(request.description());
        project.setTechStack(request.techStack());
        project.setRequiredRoles(request.requiredRoles());

        return mapToDto(projectRepository.save(project));
    }

    public ProjectDto getProjectById(Long id) {
        Project project = projectRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Проект не найден"));
        return mapToDto(project);
    }

    public List<ProjectDto> getAllProjects() {
        return projectRepository.findAll().stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    private ProjectDto mapToDto(Project project) {
        return new ProjectDto(
                project.getId(),
                project.getTitle(),
                project.getDescription(),
                project.getTechStack(),
                project.getRequiredRoles(),
                project.getOwner().getEmail()
        );
    }
}