package com.example.teamprojectunn1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeamprojectUnn1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
